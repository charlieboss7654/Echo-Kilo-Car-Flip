fx_version 'cerulean'
game 'gta5'

author 'Cowboy - Echo Kilo Studios'
description 'Flip vehicles with ox_target when they�re upside down'
version '1.1.0'

dependencies {
  'ox_target'
}

client_scripts {
  'client/client.lua'
}
