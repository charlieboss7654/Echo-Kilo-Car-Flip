local INTERACT_DISTANCE = 3.5
local LIFT_Z = 0.6
local PLAY_ANIM = true

local SAFETY_PUSH_PLAYER = true
local SAFETY_PUSH_DISTANCE = 2.5
local SAFETY_NO_COLLISION = true
local SAFETY_VEHICLE_AWAY_NUDGE = 0.8
local SAFETY_MIN_PLAYER_CLEAR = 1.8

local function IsVehicleFlipped(vehicle)
  if not DoesEntityExist(vehicle) then return false end
  if IsEntityUpsidedown(vehicle) then return true end
  if not IsVehicleOnAllWheels(vehicle) then
    local roll = GetEntityRoll(vehicle)
    if math.abs(roll) > 65.0 then return true end
  end
  local upright = GetEntityUprightValue(vehicle) or 1.0
  if upright < 0.25 then return true end
  return false
end

local function RequestEntityControl(entity, timeout)
  timeout = timeout or 2000
  local t = GetGameTimer()
  NetworkRequestControlOfEntity(entity)
  while not NetworkHasControlOfEntity(entity) and (GetGameTimer() - t) < timeout do
    NetworkRequestControlOfEntity(entity)
    Wait(10)
  end
  return NetworkHasControlOfEntity(entity)
end

local function PlayFlipAnim()
  if not PLAY_ANIM then return end
  local ped = PlayerPedId()
  local dict, anim = 'missfinale_c2ig_11', 'pushcar_offcliff_m'
  RequestAnimDict(dict)
  local start = GetGameTimer()
  while not HasAnimDictLoaded(dict) and (GetGameTimer() - start) < 1500 do Wait(10) end
  TaskPlayAnim(ped, dict, anim, 8.0, -8.0, 1200, 0, 0.0, false, false, false)
  Wait(900)
  StopAnimTask(ped, dict, anim, 1.0)
end

local function vecSub(a, b) return vector3(a.x - b.x, a.y - b.y, a.z - b.z) end
local function vecLen(v) return math.sqrt(v.x*v.x + v.y*v.y + v.z*v.z) end
local function vecNorm(v)
  local l = vecLen(v)
  if l < 0.0001 then return vector3(0.0, 1.0, 0.0) end
  return vector3(v.x/l, v.y/l, v.z/l)
end
local function groundZAt(x, y, zDefault)
  local found, gz = GetGroundZFor_3dCoord(x, y, zDefault or 1000.0, false)
  return found and gz or (zDefault or 0.0)
end

local function FlipVehicle(vehicle)
  if not DoesEntityExist(vehicle) then return false, 'no_entity' end
  if not RequestEntityControl(vehicle) then return false, 'no_control' end

  local ped = PlayerPedId()
  local pv = GetEntityCoords(ped)
  local vx, vy, vz = table.unpack(GetEntityCoords(vehicle))
  local vpos = vector3(vx, vy, vz)
  local heading = GetEntityHeading(vehicle)

  local toVeh = vecSub(vpos, pv)
  local dist = vecLen(toVeh)
  local awayDir = vecNorm(vecSub(pv, vpos))

  if SAFETY_NO_COLLISION then
    SetEntityNoCollisionEntity(ped, vehicle, true)
    SetEntityNoCollisionEntity(vehicle, ped, true)
  end

  if SAFETY_PUSH_PLAYER and dist < SAFETY_MIN_PLAYER_CLEAR then
    local planar = vector3(awayDir.x, awayDir.y, 0.0)
    local planarLen = vecLen(planar)
    local dir = (planarLen < 0.0001) and vector3(0.0, 1.0, 0.0) or vector3(planar.x/planarLen, planar.y/planarLen, 0.0)
    local target = pv + (dir * SAFETY_PUSH_DISTANCE)
    local gz = groundZAt(target.x, target.y, pv.z + 1.0)
    SetEntityCoords(ped, target.x, target.y, gz + 0.05, true, false, false, false)
  end

  FreezeEntityPosition(vehicle, true)
  SetEntityVelocity(vehicle, 0.0, 0.0, 0.0)

  local nudgeAway = vector3(-awayDir.x * SAFETY_VEHICLE_AWAY_NUDGE, -awayDir.y * SAFETY_VEHICLE_AWAY_NUDGE, 0.0)
  local newPos = vpos + nudgeAway

  SetEntityCoordsNoOffset(vehicle, newPos.x, newPos.y, newPos.z + LIFT_Z, false, false, false)
  SetEntityRotation(vehicle, 0.0, 0.0, heading, 2, true)
  Wait(60)
  SetVehicleOnGroundProperly(vehicle)
  FreezeEntityPosition(vehicle, false)

  Wait(150)
  if SAFETY_NO_COLLISION then
    SetEntityNoCollisionEntity(ped, vehicle, false)
    SetEntityNoCollisionEntity(vehicle, ped, false)
  end

  SetVehicleEngineOn(vehicle, false, true, true)
  return true
end

local function canInteract(entity, distance)
  if not entity or not DoesEntityExist(entity) then return false end
  if not IsEntityAVehicle(entity) then return false end
  if distance and distance > INTERACT_DISTANCE then return false end
  if not IsPedOnFoot(PlayerPedId()) then return false end
  if not IsVehicleSeatFree(entity, -1) then return false end
  return IsVehicleFlipped(entity)
end

AddEventHandler('onClientResourceStart', function(res)
  if res ~= GetCurrentResourceName() then return end
  CreateThread(function()
    while GetResourceState('ox_target') ~= 'started' do Wait(200) end
    exports.ox_target:addGlobalVehicle({
      {
        name = 'eks_flipvehicle:flip',
        icon = 'fa-solid fa-rotate-left',
        label = 'Flip Vehicle',
        distance = INTERACT_DISTANCE,
        canInteract = function(entity, distance, coords, name)
          return canInteract(entity, distance)
        end,
        onSelect = function(data)
          local entity = data.entity
          if not entity or not DoesEntityExist(entity) then return end
          PlayFlipAnim()
          local ok, err = FlipVehicle(entity)
          if not ok then
            local msg = (err == 'no_control') and 'Could not get control of vehicle.' or 'Flip failed.'
            TriggerEvent('chat:addMessage', { args = { '^1' .. msg } })
          end
        end
      }
    })
    print('^2[eks_flipvehicle]^7 ox_target flip option registered with safety.')
  end)
end)
